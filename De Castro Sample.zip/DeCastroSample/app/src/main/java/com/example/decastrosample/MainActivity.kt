package com.example.decastrosample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore.Audio.Radio
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import com.example.decastrosample.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
//    lateinit var etFullName: EditText
//    lateinit var etAge:EditText
//    lateinit var etEmail:EditText
//    lateinit var rbMale:RadioButton
//    lateinit var rbFemale:RadioButton
//    lateinit var tvData: TextView
//    lateinit var btnSend:Button
//    lateinit var btnClose:Button
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
//        setContentView(R.layout.activity_main)
        setContentView(binding.root)
        //Set Values
//        etFullName = findViewById(R.id.etFullName)
//        etAge = findViewById(R.id.etNumber)
//        etEmail = findViewById(R.id.etEmail)
//        rbMale = findViewById(R.id.rbMale)
//        rbFemale = findViewById(R.id.rbFemale)
//        tvData = findViewById(R.id.textView4)
//        btnSend = findViewById(R.id.btnSend)
//        btnClose = findViewById(R.id.btnClose)

        binding.btnSend.setOnClickListener{
            displayData()
        }

        binding.btnClose.setOnClickListener{
            finish()
        }

    }

    private fun displayData(){
//        var fullname = etFullName.text.toString()
//        var age = etAge.text.toString().toInt()
//        var email = etEmail.text.toString()
//        var gender = if(rbMale.isChecked){
//            "Male"
//        }else{
//            "Female"
//        }
        var fullname = binding.etFullName.toString()
        var age = binding.etNumber.toString().toInt()
        var email = binding.etEmail.toString()
        var gender = if(binding.rbMale.isChecked()){
            "Male"
        }else{
            "Female"
        }
        var data = "Full Name: " + fullname + "\n" + "Age: " + age + "\n" + "Email" + email + "\n" +
                "Gender" + gender + "\n"

        binding.textView4.text = data
    }
}